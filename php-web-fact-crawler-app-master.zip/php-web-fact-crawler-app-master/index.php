<html>
<head>
</head>
<body>
<a href="release1.php">load fact</a>

<a href="db.php">factshow</a>
</body>
</html>
